/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author alunolab11
 */
public class Mavenproject1 {

    public static void main(String[] args) {
        Aluno a1 = new Aluno("davi", "cc", "cc3mc", 1, 10, 10);
        a1.Imprimir();
    }
}
