/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.util.Random;
import java.time.Year;
/**
 *
 * @author alunolab11
 */
public class Aluno {
    private String matricula = GerarMatricula();
    private String nome;
    private String curso;
    private String turma;
    private int periodo;
    private double nota1b;
    private double nota2b;
    private double notaFinal;
    private static int Q_alunos;
    
    public Aluno(){
        Q_alunos = Q_alunos + 1;
    }
    
    public Aluno(String nome, String curso,
                 String turma, int periodo, double nota1b, double nota2b){
        this.nome = nome;
        this.curso = curso;
        this.turma = turma;
        this.periodo = periodo;
        this.nota1b = nota1b;
        this.nota2b = nota2b;
    }
    
    public void Imprimir(){
        System.out.println("Matricula: " + matricula);
        System.out.println("Nome: " + this.nome);
        System.out.println("Curso: " + this.curso);
        System.out.println("Turma: " + this.turma);
        System.out.println("Nota 1B: " + this.nota1b);
        System.out.println("Nota 2B: " + this.nota2b);
        System.out.println("Nota Final: " + this.notaFinal);
        boolean aprovacao = Passar();
        if(aprovacao == true){
            System.out.println("Status aprovacao: Aprovado " ); 
        }
        else{
            System.out.println("Status aprovacao: Reprovado");
        }
             
    }
    
    private String GerarMatricula(){
        int AnoAtual = Year.now().getValue();
        Random random = new Random();
        int nAleatorio = random.nextInt(1000);
        String matricula = AnoAtual + "-" + String.format("%03d", nAleatorio);
        return matricula;
    }
    
    private double CalcularFinal(){
        this.notaFinal = ((this.nota1b + this.nota2b) / 2.0);
        return this.notaFinal;
    }
    
    public boolean Passar(){
        double mediaFinal = CalcularFinal();
        if(mediaFinal > 6){
            this.periodo += 1;
            return true;
        }
        else{
            return false;
        }
        
    }
    
    public void setTurma(String turma){
        this.turma = turma;
    }
    
}
